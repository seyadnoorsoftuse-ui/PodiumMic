package com.seyad.podiummic

import android.app.Presentation
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.Display
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView

/**
 * Projector / HDMI / Wireless Display-ல் notes அல்லது PDF page-ஐ
 * தனித் திரையாக காட்டும் (phone-ல் controls, projector-ல் content).
 */
class ProjectorPresentation(outerContext: Context, display: Display) :
    Presentation(outerContext, display) {

    private var textView: TextView? = null
    private var imageView: ImageView? = null
    private var scroll: ScrollView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(context).apply { setBackgroundColor(Color.BLACK) }

        textView = TextView(context).apply {
            setTextColor(Color.WHITE)
            textSize = 40f
            setPadding(64, 48, 64, 48)
            setLineSpacing(0f, 1.4f)
        }
        scroll = ScrollView(context).apply { addView(textView) }

        imageView = ImageView(context).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            visibility = android.view.View.GONE
        }

        root.addView(scroll, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(imageView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(root)
    }

    fun showText(text: CharSequence, phoneFontSp: Float) {
        val tv = textView ?: return
        scroll?.visibility = android.view.View.VISIBLE
        imageView?.visibility = android.view.View.GONE
        tv.textSize = phoneFontSp * 1.6f   // projector-ல் பெரிதாக
        tv.text = text
    }

    fun showPage(bitmap: Bitmap) {
        val iv = imageView ?: return
        scroll?.visibility = android.view.View.GONE
        iv.visibility = android.view.View.VISIBLE
        iv.setImageBitmap(bitmap)
    }
}
