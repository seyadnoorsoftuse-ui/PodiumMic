package com.seyad.podiummic

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.hardware.display.DisplayManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.seyad.podiummic.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: SharedPreferences
    private var fontSize = 24f
    private var editMode = false
    private var autoScrolling = false

    // ===== PDF state =====
    private var pdfRenderer: PdfRenderer? = null
    private var pdfFd: ParcelFileDescriptor? = null
    private var pdfPage = 0
    private var pdfMode = false

    // ===== Projector =====
    private var projector: ProjectorPresentation? = null

    private val scrollRunnable = object : Runnable {
        override fun run() {
            if (autoScrolling) {
                b.notesScroll.smoothScrollBy(0, 2)
                b.notesScroll.postDelayed(this, 50)
            }
        }
    }

    private val openDoc =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { handleFile(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        // ===== 1. KEEP SCREEN ON =====
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefs = getSharedPreferences("podium", Context.MODE_PRIVATE)
        fontSize = prefs.getFloat("fontSize", 24f)
        b.notesView.textSize = fontSize
        b.notesEdit.setText(prefs.getString("notes", getString(R.string.sample_notes)))
        b.notesView.text = b.notesEdit.text

        b.btnEdit.setOnClickListener {
            if (pdfMode) exitPdfMode()
            editMode = !editMode
            if (editMode) {
                b.notesEdit.visibility = View.VISIBLE
                b.notesScroll.visibility = View.GONE
                b.btnEdit.text = getString(R.string.done)
            } else {
                prefs.edit().putString("notes", b.notesEdit.text.toString()).apply()
                b.notesView.text = b.notesEdit.text
                b.notesEdit.visibility = View.GONE
                b.notesScroll.visibility = View.VISIBLE
                b.btnEdit.text = getString(R.string.edit)
                updateProjector()
            }
        }

        b.btnFontUp.setOnClickListener { changeFont(+2f) }
        b.btnFontDown.setOnClickListener { changeFont(-2f) }

        b.btnAutoScroll.setOnClickListener {
            autoScrolling = !autoScrolling
            b.btnAutoScroll.text =
                if (autoScrolling) getString(R.string.stop_scroll) else getString(R.string.auto_scroll)
            if (autoScrolling) b.notesScroll.post(scrollRunnable)
        }

        // ===== FILE OPEN (txt / pdf / docx / pptx) =====
        b.btnOpen.setOnClickListener {
            openDoc.launch(arrayOf(
                "text/plain", "text/*",
                "application/pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                "application/msword",
                "application/vnd.ms-powerpoint"
            ))
        }

        // ===== PDF navigation =====
        b.btnPrevPage.setOnClickListener { showPdfPage(pdfPage - 1) }
        b.btnNextPage.setOnClickListener { showPdfPage(pdfPage + 1) }

        // ===== PROJECTOR =====
        b.btnProject.setOnClickListener { toggleProjector() }

        // ===== MIC -> BLUETOOTH =====
        b.btnMic.setOnClickListener {
            if (MicStreamService.isRunning) stopMic() else startMicWithPermission()
        }
        b.gainSlider.addOnChangeListener { _, value, _ ->
            MicStreamService.gain = value
            b.gainLabel.text = getString(R.string.gain_fmt, value)
        }
        b.gainSlider.value = 2.0f
    }

    // ---------- FILE HANDLING ----------

    private fun handleFile(uri: Uri) {
        val name = FileLoader.fileName(this, uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        try {
            when (ext) {
                "pdf" -> openPdf(uri, name)
                "docx" -> showLoadedText(FileLoader.loadDocx(this, uri), name)
                "pptx" -> showLoadedText(FileLoader.loadPptx(this, uri), name)
                "txt", "md", "csv", "log", "json", "xml", "html" ->
                    showLoadedText(FileLoader.loadPlainText(this, uri), name)
                "doc", "ppt" ->
                    Toast.makeText(this, R.string.old_format, Toast.LENGTH_LONG).show()
                else ->
                    showLoadedText(FileLoader.loadPlainText(this, uri), name)
            }
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.open_failed, e.message), Toast.LENGTH_LONG).show()
        }
    }

    private fun showLoadedText(text: String, name: String) {
        if (text.isBlank()) {
            Toast.makeText(this, R.string.empty_file, Toast.LENGTH_LONG).show()
            return
        }
        exitPdfMode()
        b.notesEdit.setText(text)
        b.notesView.text = text
        prefs.edit().putString("notes", text).apply()
        b.notesScroll.scrollTo(0, 0)
        Toast.makeText(this, getString(R.string.loaded_fmt, name), Toast.LENGTH_SHORT).show()
        updateProjector()
    }

    // ---------- PDF ----------

    private fun openPdf(uri: Uri, name: String) {
        closePdf()
        pdfFd = contentResolver.openFileDescriptor(uri, "r")
        val fd = pdfFd ?: return
        pdfRenderer = PdfRenderer(fd)
        pdfMode = true
        editMode = false
        b.notesEdit.visibility = View.GONE
        b.notesScroll.visibility = View.GONE
        b.pdfView.visibility = View.VISIBLE
        b.pdfNav.visibility = View.VISIBLE
        b.btnEdit.text = getString(R.string.edit)
        Toast.makeText(this, getString(R.string.loaded_fmt, name), Toast.LENGTH_SHORT).show()
        showPdfPage(0)
    }

    private fun showPdfPage(index: Int) {
        val renderer = pdfRenderer ?: return
        if (index < 0 || index >= renderer.pageCount) return
        pdfPage = index
        val bmp = renderPdfPage(index)
        b.pdfView.setImageBitmap(bmp)
        b.pageInfo.text = getString(R.string.page_fmt, index + 1, renderer.pageCount)
        projector?.showPage(bmp)
    }

    private fun renderPdfPage(index: Int): Bitmap {
        val renderer = pdfRenderer!!
        renderer.openPage(index).use { page ->
            val scale = 1600f / page.width
            val bmp = Bitmap.createBitmap(
                (page.width * scale).toInt(),
                (page.height * scale).toInt(),
                Bitmap.Config.ARGB_8888
            )
            Canvas(bmp).drawColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        }
    }

    private fun exitPdfMode() {
        if (!pdfMode) return
        pdfMode = false
        closePdf()
        b.pdfView.visibility = View.GONE
        b.pdfNav.visibility = View.GONE
        b.notesScroll.visibility = View.VISIBLE
    }

    private fun closePdf() {
        try { pdfRenderer?.close() } catch (_: Exception) {}
        try { pdfFd?.close() } catch (_: Exception) {}
        pdfRenderer = null
        pdfFd = null
        pdfPage = 0
    }

    // ---------- PROJECTOR ----------

    private fun toggleProjector() {
        if (projector != null) {
            projector?.dismiss()
            projector = null
            b.btnProject.text = getString(R.string.project)
            return
        }
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val displays = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)
        if (displays.isEmpty()) {
            Toast.makeText(this, R.string.no_display, Toast.LENGTH_LONG).show()
            return
        }
        projector = ProjectorPresentation(this, displays[0]).also {
            it.setOnDismissListener {
                projector = null
                b.btnProject.text = getString(R.string.project)
            }
            it.show()
        }
        b.btnProject.text = getString(R.string.project_stop)
        updateProjector()
    }

    private fun updateProjector() {
        val p = projector ?: return
        if (pdfMode && pdfRenderer != null) p.showPage(renderPdfPage(pdfPage))
        else p.showText(b.notesView.text, fontSize)
    }

    // ---------- FONT ----------

    private fun changeFont(delta: Float) {
        fontSize = (fontSize + delta).coerceIn(14f, 72f)
        b.notesView.textSize = fontSize
        b.notesEdit.textSize = fontSize
        prefs.edit().putFloat("fontSize", fontSize).apply()
        updateProjector()
    }

    // ---------- MIC ----------

    private fun startMicWithPermission() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) needed += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.POST_NOTIFICATIONS
        val notGranted = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, notGranted.toTypedArray(), 100)
            return
        }
        startMic()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) startMic()
        else Toast.makeText(this, R.string.perm_needed, Toast.LENGTH_LONG).show()
    }

    private fun startMic() {
        if (!isBluetoothOutputConnected()) {
            Toast.makeText(this, R.string.connect_bt_first, Toast.LENGTH_LONG).show()
        }
        val i = Intent(this, MicStreamService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        b.btnMic.text = getString(R.string.mic_stop)
        b.micStatus.text = getString(R.string.mic_live)
    }

    private fun stopMic() {
        stopService(Intent(this, MicStreamService::class.java))
        b.btnMic.text = getString(R.string.mic_start)
        b.micStatus.text = getString(R.string.mic_off)
    }

    private fun isBluetoothOutputConnected(): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
        }
    }

    override fun onResume() {
        super.onResume()
        if (MicStreamService.isRunning) {
            b.btnMic.text = getString(R.string.mic_stop)
            b.micStatus.text = getString(R.string.mic_live)
        }
    }

    override fun onDestroy() {
        projector?.dismiss()
        projector = null
        closePdf()
        super.onDestroy()
    }
}
