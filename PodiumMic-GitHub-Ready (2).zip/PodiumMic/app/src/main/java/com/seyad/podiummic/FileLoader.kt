package com.seyad.podiummic

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.zip.ZipInputStream

/**
 * TXT / DOCX / PPTX files-ஐ plain text-ஆக மாற்றும் helper.
 * DOCX, PPTX = உள்ளே XML இருக்கும் zip files —
 * library இல்லாமல் நேரடியாக text எடுக்கிறோம்.
 */
object FileLoader {

    fun fileName(ctx: Context, uri: Uri): String {
        var name = "file"
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) name = c.getString(idx) ?: "file"
        }
        return name
    }

    /** Plain text / markdown / csv */
    fun loadPlainText(ctx: Context, uri: Uri): String {
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            return BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).readText()
        }
        return ""
    }

    /** DOCX: word/document.xml -> paragraphs */
    fun loadDocx(ctx: Context, uri: Uri): String {
        val xml = readZipEntry(ctx, uri, "word/document.xml") ?: return ""
        var t = xml
            .replace(Regex("<w:br[^>]*/>"), "\n")
            .replace(Regex("<w:tab[^>]*/>"), "\t")
            .replace("</w:p>", "\n")
        t = t.replace(Regex("<[^>]+>"), "")
        return decodeEntities(t).lines()
            .joinToString("\n") { it.trimEnd() }
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }

    /** PPTX: ppt/slides/slideN.xml -> "— Slide N —" + text */
    fun loadPptx(ctx: Context, uri: Uri): String {
        val slides = sortedMapOf<Int, String>()
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            ZipInputStream(ins).use { zip ->
                var e = zip.nextEntry
                val re = Regex("ppt/slides/slide(\\d+)\\.xml")
                while (e != null) {
                    val m = re.matchEntire(e.name)
                    if (m != null) {
                        val num = m.groupValues[1].toInt()
                        slides[num] = zip.readBytes().toString(Charsets.UTF_8)
                    }
                    e = zip.nextEntry
                }
            }
        }
        if (slides.isEmpty()) return ""
        val sb = StringBuilder()
        for ((num, xml) in slides) {
            sb.append("━━━ Slide $num ━━━\n")
            // ஒவ்வொரு paragraph (<a:p>)-ஐயும் ஒரு line-ஆக
            val paras = xml.split("</a:p>")
            for (p in paras) {
                val texts = Regex("<a:t>(.*?)</a:t>", RegexOption.DOT_MATCHES_ALL)
                    .findAll(p).map { it.groupValues[1] }.joinToString("")
                if (texts.isNotBlank()) sb.append(decodeEntities(texts).trim()).append("\n")
            }
            sb.append("\n")
        }
        return sb.toString().trim()
    }

    private fun readZipEntry(ctx: Context, uri: Uri, entryName: String): String? {
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            ZipInputStream(ins).use { zip ->
                var e = zip.nextEntry
                while (e != null) {
                    if (e.name == entryName) return zip.readBytes().toString(Charsets.UTF_8)
                    e = zip.nextEntry
                }
            }
        }
        return null
    }

    private fun decodeEntities(s: String): String = s
        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&apos;", "'").replace("&#10;", "\n")
}
